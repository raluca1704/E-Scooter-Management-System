
void Test_All();

void Test_Add();

void Test_Delete();

void Test_Edit();

void Test_Search_by_location();

void Test_Filter_by_commissioning_date();

void Test_Filter_by_kilometer();

void Test_Sort_by_date();

void Test_Modify_condition();
