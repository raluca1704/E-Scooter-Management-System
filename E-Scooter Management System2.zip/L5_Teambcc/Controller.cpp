#include "Controller.h"
#include <exception>

using namespace Controller;

Electric_scooter_Controller::Electric_scooter_Controller(shared_ptr<Electric_scooter_Repo> &new_repo) {

    this->Scooter_Repo = new_repo;

}

void Electric_scooter_Controller::add(string scooter_identifier, string scooter_model, string scooter_commissioning_date, int scooter_kilometer, string scooter_location, string scooter_condition) {

    Electric_scooter new_scooter(scooter_identifier, scooter_model, scooter_commissioning_date, scooter_kilometer, scooter_location,scooter_condition);

    if(!Scooter_Repo->exits(new_scooter.get_identifier())){

        Scooter_Repo->add(new_scooter);

    }
}

void Electric_scooter_Controller::del(string scooter_identifier) {

    if(Scooter_Repo->exits(scooter_identifier)){

        Scooter_Repo->del(scooter_identifier);

    }

}

void Electric_scooter_Controller::edit(string scooter_identifier, string scooter_model,string scooter_commissioning_date, int scooter_kilometer,string scooter_location, string scooter_condition) {

    if(Scooter_Repo->exits(scooter_identifier)){

        Scooter_Repo->del(scooter_identifier);
        Electric_scooter new_scooter(scooter_identifier, scooter_model, scooter_commissioning_date, scooter_kilometer, scooter_location,scooter_condition);
        Scooter_Repo->add(new_scooter);

    }

}

vector <Electric_scooter> Electric_scooter_Controller::search_by_location(const string &scooter_location) {

    vector <Electric_scooter> scooters;
    scooters = Scooter_Repo->search_by_location(scooter_location);
    return scooters;

}


vector <Electric_scooter> Electric_scooter_Controller::filter_by_commissioning_date(const string &scooter_commissioning_date) {

    vector <Electric_scooter> scooters;
    scooters = Scooter_Repo->filter_by_commissioning_date(scooter_commissioning_date);
    return scooters;

}

vector <Electric_scooter> Electric_scooter_Controller::filter_by_kilometer(int scooter_kilometer) {

    vector <Electric_scooter> scooters;
    scooters = Scooter_Repo->filter_by_kilometer(scooter_kilometer);
    return scooters;

}

vector <Electric_scooter> Electric_scooter_Controller::sort_by_commissioning_date(){

    vector <Electric_scooter> scooters;
    scooters = Scooter_Repo->sort_by_commissioning_date();
    return scooters;

}

vector <Electric_scooter> Electric_scooter_Controller::get_all() {

    vector <Electric_scooter> scooters;
    scooters = Scooter_Repo->get_all();
    return scooters;

}


void Electric_scooter_Controller::modify_condition(string scooter_identifier, string scooter_condition){

    if(Scooter_Repo->exits(scooter_identifier)){

        Scooter_Repo->modify_condition(scooter_identifier,scooter_condition);

    }

}