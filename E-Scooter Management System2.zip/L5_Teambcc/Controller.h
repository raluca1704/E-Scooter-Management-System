#include "Repository.h"
#include <memory>

using namespace Repository;

namespace Controller {

    class Electric_scooter_Controller{

    private:

        shared_ptr <Electric_scooter_Repo> Scooter_Repo;

    public:

        Electric_scooter_Controller(shared_ptr <Electric_scooter_Repo> &new_repo);

        void add(string scooter_identifier, string scooter_model, string scooter_commissioning_date, int scooter_kilometer, string scooter_location, string scooter_condition);

        void del(string scooter_identifier);

        void edit(string scooter_identifier, string scooter_model, string scooter_commissioning_date, int scooter_kilometer, string scooter_location, string scooter_condition);

        vector <Electric_scooter> search_by_location(const string& scooter_location);

        vector <Electric_scooter> filter_by_commissioning_date(const string& scooter_commissioning_date);

        vector <Electric_scooter> filter_by_kilometer(int scooter_kilometer);

        vector <Electric_scooter> sort_by_commissioning_date();

        vector <Electric_scooter> get_all();

        void modify_condition(string scooter_identifier, string scooter_condition);


    };

}