#include "Repository.h"
#include <vector>
#include <algorithm>

using namespace Repository;

void Electric_scooter_Repo::add(Electric_scooter new_scooter) {

    Electric_scooters.push_back(new_scooter);

}

void Electric_scooter_Repo::del(const string& deleted_scooter_identifier) {

    for (auto scooter = Electric_scooters.begin(); scooter < Electric_scooters.end(); scooter++) {

        if(scooter->get_identifier() == deleted_scooter_identifier){

            Electric_scooters.erase(scooter);

        }
    }

}

void Electric_scooter_Repo::edit(Electric_scooter edited_scooter, const string& edited_scooter_identifier) {

    del(edited_scooter_identifier);
    add(edited_scooter);

}

vector <Electric_scooter> Electric_scooter_Repo::get_all() {

    vector <Electric_scooter> scooters;
    for(auto& scooter: Electric_scooters){

        scooters.push_back(scooter);

    }

    return scooters;

}

vector <Electric_scooter> Electric_scooter_Repo::search_by_location(const string& scooter_location) {

    vector <Electric_scooter> scooters;
    for(auto& scooter: Electric_scooters){

        if(scooter.get_location() == scooter_location) {

            scooters.push_back(scooter);

        }

    }

    return scooters;

}

vector <Electric_scooter> Electric_scooter_Repo::filter_by_commissioning_date(const string& scooter_commissioning_date){

    vector <Electric_scooter> scooters;
    for(auto& scooter: Electric_scooters){

        if(scooter.get_commissioning_date() < scooter_commissioning_date) {

            scooters.push_back(scooter);

        }

    }

    return scooters;

}

vector <Electric_scooter> Electric_scooter_Repo::filter_by_kilometer(int scooter_kilometer){

    vector <Electric_scooter> scooters;
    for(auto& scooter: Electric_scooters){

        if(scooter.get_kilometer() < scooter_kilometer) {

            scooters.push_back(scooter);

        }

    }

    return scooters;

}

vector <Electric_scooter> Electric_scooter_Repo::sort_by_commissioning_date() {

    vector <Electric_scooter> scooters = get_all();
    sort(scooters.begin(), scooters.end(), [](Electric_scooter scooter1, Electric_scooter scooter2){return stoi(scooter1.get_commissioning_date())<stoi(scooter2.get_commissioning_date());});
    return scooters;

}

bool Electric_scooter_Repo::exits(const string& scooter_identifier) {

    for (auto& scooter: Electric_scooters){


        if(scooter_identifier == scooter.get_identifier()){

            return true;

        }
    }

    return false;

}

void Electric_scooter_Repo::modify_condition(string scooter_identifier, string scooter_condition) {

    for (auto& scooter: Electric_scooters){


        if(scooter_identifier == scooter.get_identifier()){

            scooter.set_condition(scooter_condition);

        }
    }

}