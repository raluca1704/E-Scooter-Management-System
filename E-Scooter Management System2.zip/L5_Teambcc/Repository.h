#include "Domain.h"
#include <vector>

using namespace std;
using namespace Domain;

namespace Repository {

    class Electric_scooter_Repo{

    private:

        vector <Electric_scooter> Electric_scooters;

    public:

        void add(Electric_scooter new_scooter);

        void del(const string& deleted_scooter_identifier);

        void edit(Electric_scooter edited_scooter, const string& edited_scooter_identifier);

        vector <Electric_scooter> get_all();

        vector <Electric_scooter> search_by_location(const string& scooter_location);

        vector <Electric_scooter> filter_by_commissioning_date(const string& scooter_commissioning_date);

        vector <Electric_scooter> filter_by_kilometer(int scooter_kilometer);

        vector <Electric_scooter> sort_by_commissioning_date();

        void modify_condition(string scooter_identifier, string scooter_condition);

        bool exits(const string& scooter_identifier);

    };

}
