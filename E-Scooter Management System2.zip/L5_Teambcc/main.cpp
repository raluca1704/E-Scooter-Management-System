#include "UI.h"
#include "Tests.h"
#include <memory>

using namespace UI;

int main() {

    shared_ptr <Electric_scooter_Repo> Electric_Scooter_Repository = make_shared<Electric_scooter_Repo>();
    shared_ptr <Electric_scooter_Controller> Electric_Scooter_Controller = make_shared<Electric_scooter_Controller>(Electric_Scooter_Repository);

    Electric_Scooter_Repository->add(Electric_scooter("XXX", "X6", "20220302", 15002, "Berlin", "reserved"));
    Electric_Scooter_Repository->add(Electric_scooter("MGL", "S10", "20240312", 1, "Dubai", "waiting"));
    Electric_Scooter_Repository->add(Electric_scooter("BMW", "E92", "20010322", 1500982, "Slobozia", "parked"));
    Electric_Scooter_Repository->add(Electric_scooter("PCY", "Z100", "21001231", 0, "Milano", "waiting"));
    Electric_Scooter_Repository->add(Electric_scooter("DCA", "1310", "19801102", 22000002, "Medias", "out-of-use"));
    Electric_Scooter_Repository->add(Electric_scooter("TYO", "X69", "20150302", 300002, "Amsterdam", "in-use"));
    Electric_Scooter_Repository->add(Electric_scooter("TTO", "Y69", "20180322", 3012002, "Riad", "waiting"));
    Electric_Scooter_Repository->add(Electric_scooter("MMM", "MM66", "20290101", 0, "Kiev", "waiting"));
    Electric_Scooter_Repository->add(Electric_scooter("ZZZ", "Z01", "19990406", 1500000, "Amsterdam", "in-use"));
    Electric_Scooter_Repository->add(Electric_scooter("OLD", "01", "18000305", 199922291, "Hamburg", "out-of-use"));

    Test_All();

    Electric_scooter_UI User_Interface(Electric_Scooter_Controller);
    User_Interface.RUN();

    return 0;
}
